import app

app.menu()